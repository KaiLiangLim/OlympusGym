package com.fdm.MySoloProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySoloProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySoloProjectApplication.class, args);
	}

}
