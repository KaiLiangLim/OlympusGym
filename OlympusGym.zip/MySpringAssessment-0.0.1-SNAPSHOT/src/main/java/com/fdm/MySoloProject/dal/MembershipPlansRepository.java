package com.fdm.MySoloProject.dal;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fdm.MySoloProject.model.MembershipPlans;


public interface MembershipPlansRepository extends JpaRepository<MembershipPlans, Integer> {

}
