package com.fdm.MySoloProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySoloProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
